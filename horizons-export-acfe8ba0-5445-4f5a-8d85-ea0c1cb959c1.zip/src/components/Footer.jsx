
import React from 'react';
import { Instagram, Facebook, Send, Phone, Mail, MapPin, MessageCircle } from 'lucide-react';

const Footer = () => {
  const scrollToSection = (e, href) => {
    e.preventDefault();
    const element = document.querySelector(href);
    if (element) {
      const offset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;
      
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  const quickLinks = [
    { label: 'Inicio', href: '#inicio' },
    { label: 'Destinos', href: '#destinos' },
    { label: 'Proceso', href: '#proceso' },
    { label: 'Contacto', href: '#contacto' }
  ];

  const socialLinks = [
    { icon: Instagram, href: 'https://instagram.com/velari.tur', label: 'Instagram' },
    { icon: Facebook, href: 'https://facebook.com', label: 'Facebook' },
    { icon: Send, href: 'https://tiktok.com', label: 'TikTok' }
  ];

  return (
    <footer className="bg-[#1E5A96] text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Branding */}
          <div>
            <span className="text-3xl font-bold mb-4 block">Velari</span>
            <p className="text-white/80 mb-6">
              Tu agencia de viajes personalizada. Hacemos realidad tus sueños de viaje.
            </p>
            <a
              href="https://wa.me/543884335569"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-[#FFB700] hover:bg-[#e5a600] text-gray-900 font-bold px-6 py-3 rounded-full transition-all duration-300 hover:scale-105"
            >
              <MessageCircle size={18} />
              WhatsApp
            </a>
          </div>

          {/* Quick Links */}
          <div>
            <span className="text-xl font-bold mb-4 block">Enlaces Rápidos</span>
            <nav>
              <ul className="space-y-3">
                {quickLinks.map((link) => (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      onClick={(e) => scrollToSection(e, link.href)}
                      className="text-white/80 hover:text-[#FFB700] transition-colors duration-200"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </nav>
          </div>

          {/* Contact Info */}
          <div>
            <span className="text-xl font-bold mb-4 block">Contacto</span>
            <ul className="space-y-3">
              <li className="flex items-start gap-3 text-white/80">
                <Mail size={20} className="mt-1 flex-shrink-0" />
                <span>Velariturismo@gmail.com</span>
              </li>
              <li className="flex items-start gap-3 text-white/80">
                <Phone size={20} className="mt-1 flex-shrink-0" />
                <span>+54 388 433-5569</span>
              </li>
              <li className="flex items-start gap-3 text-white/80">
                <MapPin size={20} className="mt-1 flex-shrink-0" />
                <span>San Salvador de Jujuy, Jujuy, Argentina</span>
              </li>
            </ul>
          </div>

          {/* Social Media */}
          <div>
            <span className="text-xl font-bold mb-4 block">Síguenos</span>
            <div className="flex gap-4">
              {socialLinks.map((social) => {
                const Icon = social.icon;
                return (
                  <a
                    key={social.label}
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={social.label}
                    className="w-12 h-12 bg-white/10 hover:bg-[#FFB700] rounded-full flex items-center justify-center transition-all duration-300 hover:scale-110"
                  >
                    <Icon size={20} />
                  </a>
                );
              })}
            </div>
          </div>
        </div>

        <div className="border-t border-white/20 pt-8 text-center text-white/60">
          <p>&copy; {new Date().getFullYear()} Velari. Todos los derechos reservados.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
