
import React from 'react';
import { motion } from 'framer-motion';
import { KeyRound as UserRound, Clock, Shield } from 'lucide-react';

const BenefitsSection = () => {
  const benefits = [
    {
      icon: UserRound,
      title: 'Asesor personal dedicado',
      description: 'Un experto en viajes te acompañará en cada paso, personalizando tu experiencia según tus preferencias y presupuesto.'
    },
    {
      icon: Clock,
      title: 'Reservas online 24/7',
      description: 'Accede a nuestro sistema de reservas en cualquier momento y desde cualquier lugar. Tu próxima aventura está a un clic.'
    },
    {
      icon: Shield,
      title: 'Pagos seguros y confiables',
      description: 'Plataforma de pagos encriptada y protegida. Tu información y transacciones están completamente seguras con nosotros.'
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-[#1E5A96] mb-4">
            ¿Por qué elegir Velari?
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Ofrecemos una experiencia única en planificación de viajes
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
                className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-[#1E5A96] to-[#2c7ac4] rounded-2xl flex items-center justify-center mb-6 mx-auto">
                  <Icon size={32} className="text-white" />
                </div>
                
                <h3 className="text-xl font-bold text-gray-800 mb-3 text-center">
                  {benefit.title}
                </h3>
                
                <p className="text-gray-600 text-center leading-relaxed">
                  {benefit.description}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default BenefitsSection;
