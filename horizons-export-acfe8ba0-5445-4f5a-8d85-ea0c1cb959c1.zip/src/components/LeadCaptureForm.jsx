
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { CheckCircle2, Loader2 } from 'lucide-react';
import { useSupabaseLead } from '@/hooks/useSupabaseLead';
import { useToast } from '@/components/ui/use-toast';

const LeadCaptureForm = () => {
  const { toast } = useToast();
  const { submitLead, loading } = useSupabaseLead();
  
  const [formData, setFormData] = useState({
    nombre: '',
    email: '',
    destino: '',
    fecha: ''
  });

  const [errors, setErrors] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  const destinations = [
    'Bali',
    'Machu Picchu',
    'Santorini',
    'Maldivas',
    'Costa Rica',
    'París'
  ];

  const validateForm = () => {
    const newErrors = {};

    if (!formData.nombre.trim()) {
      newErrors.nombre = 'El nombre es requerido';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'El email es requerido';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Email inválido';
    }

    if (!formData.destino) {
      newErrors.destino = 'Selecciona un destino';
    }

    if (!formData.fecha) {
      newErrors.fecha = 'La fecha es requerida';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (validateForm()) {
      const result = await submitLead(formData);

      if (result.success) {
        setIsSubmitted(true);
        toast({
          title: "¡Éxito!",
          description: "¡Gracias! Tu solicitud ha sido enviada correctamente.",
          className: "bg-green-50 border-green-200 text-green-900",
        });

        // Reset form state after showing success message
        setFormData({ nombre: '', email: '', destino: '', fecha: '' });
        
        // Return to form after delay if desired, or keep "Submitted" state
        setTimeout(() => {
          setIsSubmitted(false);
        }, 5000);
      } else {
        toast({
          variant: "destructive",
          title: "Error",
          description: result.error || "Hubo un problema al enviar tu solicitud. Por favor intenta de nuevo.",
        });
      }
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  if (isSubmitted) {
    return (
      <section id="contacto" className="py-20 bg-gradient-to-b from-gray-50 to-white">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-2xl mx-auto bg-white rounded-2xl shadow-xl p-12 text-center"
          >
            <CheckCircle2 size={64} className="text-green-500 mx-auto mb-6" />
            <h3 className="text-3xl font-bold text-gray-800 mb-4">
              ¡Solicitud Recibida!
            </h3>
            <p className="text-lg text-gray-600 mb-6">
              Tu asesor personal se pondrá en contacto contigo pronto para comenzar a planificar tu viaje soñado.
            </p>
            <Button 
              onClick={() => setIsSubmitted(false)}
              variant="outline"
              className="mt-4"
            >
              Enviar otra solicitud
            </Button>
          </motion.div>
        </div>
      </section>
    );
  }

  return (
    <section id="contacto" className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-[#1E5A96] mb-4">
            Comienza tu aventura
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Completa el formulario y recibe una asesoría gratuita personalizada
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="max-w-2xl mx-auto bg-white rounded-2xl shadow-xl p-8 md:p-12"
        >
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Nombre */}
            <div>
              <Label htmlFor="nombre" className="text-gray-700 font-medium mb-2 block">
                Nombre completo *
              </Label>
              <input
                id="nombre"
                name="nombre"
                type="text"
                disabled={loading}
                value={formData.nombre}
                onChange={handleChange}
                className={`w-full px-4 py-3 rounded-lg border bg-white text-gray-900 placeholder-gray-400 ${
                  errors.nombre ? 'border-red-500' : 'border-gray-300'
                } focus:outline-none focus:ring-2 focus:ring-[#1E5A96] focus:border-transparent disabled:opacity-50`}
                placeholder="Juan Pérez"
              />
              {errors.nombre && (
                <p className="text-red-500 text-sm mt-1">{errors.nombre}</p>
              )}
            </div>

            {/* Email */}
            <div>
              <Label htmlFor="email" className="text-gray-700 font-medium mb-2 block">
                Correo electrónico *
              </Label>
              <input
                id="email"
                name="email"
                type="email"
                disabled={loading}
                value={formData.email}
                onChange={handleChange}
                className={`w-full px-4 py-3 rounded-lg border bg-white text-gray-900 placeholder-gray-400 ${
                  errors.email ? 'border-red-500' : 'border-gray-300'
                } focus:outline-none focus:ring-2 focus:ring-[#1E5A96] focus:border-transparent disabled:opacity-50`}
                placeholder="tu@email.com"
              />
              {errors.email && (
                <p className="text-red-500 text-sm mt-1">{errors.email}</p>
              )}
            </div>

            {/* Destino */}
            <div>
              <Label htmlFor="destino" className="text-gray-700 font-medium mb-2 block">
                Destino de interés *
              </Label>
              <select
                id="destino"
                name="destino"
                disabled={loading}
                value={formData.destino}
                onChange={handleChange}
                className={`w-full px-4 py-3 rounded-lg border bg-white text-gray-900 ${
                  errors.destino ? 'border-red-500' : 'border-gray-300'
                } focus:outline-none focus:ring-2 focus:ring-[#1E5A96] focus:border-transparent disabled:opacity-50`}
              >
                <option value="">Selecciona un destino</option>
                {destinations.map((dest) => (
                  <option key={dest} value={dest}>
                    {dest}
                  </option>
                ))}
              </select>
              {errors.destino && (
                <p className="text-red-500 text-sm mt-1">{errors.destino}</p>
              )}
            </div>

            {/* Fecha */}
            <div>
              <Label htmlFor="fecha" className="text-gray-700 font-medium mb-2 block">
                Fecha aproximada de viaje *
              </Label>
              <input
                id="fecha"
                name="fecha"
                type="date"
                disabled={loading}
                value={formData.fecha}
                onChange={handleChange}
                min={new Date().toISOString().split('T')[0]}
                className={`w-full px-4 py-3 rounded-lg border bg-white text-gray-900 ${
                  errors.fecha ? 'border-red-500' : 'border-gray-300'
                } focus:outline-none focus:ring-2 focus:ring-[#1E5A96] focus:border-transparent disabled:opacity-50`}
              />
              {errors.fecha && (
                <p className="text-red-500 text-sm mt-1">{errors.fecha}</p>
              )}
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-[#FFB700] hover:bg-[#e5a600] text-gray-900 font-bold text-lg py-6 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 disabled:hover:scale-100 disabled:opacity-70 disabled:cursor-not-allowed"
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <Loader2 className="animate-spin" size={20} />
                  Enviando...
                </span>
              ) : (
                "¡Quiero mi asesoría gratuita!"
              )}
            </Button>
          </form>
        </motion.div>
      </div>
    </section>
  );
};

export default LeadCaptureForm;
