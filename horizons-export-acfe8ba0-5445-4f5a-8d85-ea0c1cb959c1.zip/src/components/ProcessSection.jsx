
import React from 'react';
import { motion } from 'framer-motion';
import { MessageSquare, Calendar, Plane } from 'lucide-react';

const ProcessSection = () => {
  const steps = [
    {
      number: '01',
      icon: MessageSquare,
      title: 'Cuéntanos tu sueño',
      description: 'Comparte tus ideas, preferencias y presupuesto. Queremos conocer exactamente qué tipo de experiencia buscas.'
    },
    {
      number: '02',
      icon: Calendar,
      title: 'Nosotros planificamos',
      description: 'Nuestro equipo diseñará un itinerario personalizado, reservará hoteles, vuelos y actividades perfectas para ti.'
    },
    {
      number: '03',
      icon: Plane,
      title: '¡A viajar!',
      description: 'Disfruta tu aventura con la tranquilidad de tener soporte 24/7. Solo preocúpate por crear recuerdos inolvidables.'
    }
  ];

  return (
    <section id="proceso" className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-[#1E5A96] mb-4">
            Nuestro Proceso
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Tres simples pasos para convertir tus sueños en realidad
          </p>
        </motion.div>

        <div className="relative max-w-5xl mx-auto">
          {/* Timeline connector for desktop */}
          <div className="hidden lg:block absolute top-32 left-0 right-0 h-1 bg-gradient-to-r from-[#1E5A96] via-[#FFB700] to-[#1E5A96]" style={{ transform: 'translateY(-50%)' }} />

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 lg:gap-8">
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  className="relative"
                >
                  {/* Step number */}
                  <div className="text-center mb-6">
                    <span className="inline-block text-6xl font-bold text-[#FFB700]/20">
                      {step.number}
                    </span>
                  </div>

                  {/* Icon */}
                  <div className="relative z-10 w-24 h-24 bg-gradient-to-br from-[#1E5A96] to-[#2c7ac4] rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl">
                    <Icon size={40} className="text-white" />
                  </div>

                  {/* Content */}
                  <div className="text-center">
                    <h3 className="text-2xl font-bold text-gray-800 mb-4">
                      {step.title}
                    </h3>
                    <p className="text-gray-600 leading-relaxed">
                      {step.description}
                    </p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProcessSection;
