
import React from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import BenefitsSection from '@/components/BenefitsSection';
import DestinationsGallery from '@/components/DestinationsGallery';
import ProcessSection from '@/components/ProcessSection';
import LeadCaptureForm from '@/components/LeadCaptureForm';
import Footer from '@/components/Footer';

const HomePage = () => {
  return (
    <>
      <Helmet>
        <title>Velari - Tu Agencia de Viajes Personalizada | Descubre el Mundo</title>
        <meta
          name="description"
          content="Velari es tu agencia de viajes personalizada. Ofrecemos asesoría experta, reservas 24/7 y experiencias inolvidables en destinos como Bali, Maldivas, París y más. Planifica tu próxima aventura con nosotros."
        />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&display=swap"
          rel="stylesheet"
        />
      </Helmet>

      <div className="min-h-screen">
        <Header />
        <main>
          <Hero />
          <BenefitsSection />
          <DestinationsGallery />
          <ProcessSection />
          <LeadCaptureForm />
        </main>
        <Footer />
      </div>
    </>
  );
};

export default HomePage;
